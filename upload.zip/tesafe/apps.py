from django.apps import AppConfig


class TesafeConfig(AppConfig):
    name = 'tesafe'
